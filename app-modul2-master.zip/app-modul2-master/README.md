<strong> Aplikasi Modul 2 - Java - Fix </strong> <br/>

Aplikasi ini hanya digunakan sebagai acuan, tidak untuk diedit dan dikembangkan sebagai tugas praktikum atau modul - modul selanjutnya <br />
Apabila ada praktikan yang menggunakannya sebagaimana point daitas, maka asisten berhak <strong>mengurangi nilai</strong> pada modul yang bersangkutan <br />
<br/>
Terimakasih
